// hooks/useLiveLocationPing.js
import { useEffect, useRef } from 'react';
import { attendanceAPI } from '../services/api';

const PING_INTERVAL_MS = 10 * 60 * 1000; // matches the backend's ~10 min cadence

export function useLiveLocationPing(isCheckedIn) {
  const intervalRef = useRef(null);

  useEffect(() => {
    const sendPing = () => {
      if (!navigator.geolocation) return;
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          try {
            await attendanceAPI.trackLocation({
              latitude: pos.coords.latitude,
              longitude: pos.coords.longitude,
              accuracy: pos.coords.accuracy,
            });
          } catch (err) {
            // e.g. server says already checked out — safe to ignore
            console.warn('Location ping failed:', err?.response?.data?.message || err.message);
          }
        },
        (err) => console.warn('Geolocation error:', err.message),
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 }
      );
    };

    if (isCheckedIn) {
      sendPing(); // fire one immediately on check-in
      intervalRef.current = setInterval(sendPing, PING_INTERVAL_MS);
      // catch up if the tab was backgrounded/throttled and regains focus
      document.addEventListener('visibilitychange', handleVisibility);
    }

    function handleVisibility() {
      if (document.visibilityState === 'visible') sendPing();
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [isCheckedIn]);
}